import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Student extends Person {
    private List<Course> courses;
    private Map<Course, Grade> grades;

    public Student(String name, String id) {
        super(name, id);
        courses = new ArrayList<>();
        setGrades(new HashMap<>());
    }

    public Map<Course, Grade> getGrades() {
        return grades;

    }

    public void setGrades(Map<Course, Grade> grades) {
        this.grades = grades;

    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addGrade(Course course, Grade grade) {
        getGrades().put(course, grade);
    }

    public void displayInfo() {
        System.out.println("Student Name: " + getName());
        System.out.println("Student ID: " + getId());
    }
}
