import java.util.ArrayList;
import java.util.List;

public class StudentManagementSystem {
    private List<Student> students;
    private List<Course> courses;

    public StudentManagementSystem() {
        students = new ArrayList<>();
        courses = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void editStudent(String id, String newName) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                student.setName(newName);
                break;
            }
        }
    }

    public void deleteStudent(String id) {
        for (int i = 0; i < students.size(); i++) {
            Student currentStudent = students.get(i);
            if (currentStudent.getId().equals(id)) {
                students.remove(i);
                break;
            }
        }
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void recordGrade(String studentId, Course course, Grade grade) {
        for (Student student : students) {
            if (student.getId().equals(studentId)) {
                student.addGrade(course, grade);
                break;
            }
        }
    }

    public double calculateAverageGrade(String studentId) {
        for (Student student : students) {
            if (student.getId().equals(studentId)) {
                double total = 0;
                int count = 0;
                for (Grade grade : student.getGrades().values()) {
                    total += grade.getScore();
                    count++;
                }
                return count == 0 ? 0 : total / count;
            }
        }
        return 0;
    }
}
