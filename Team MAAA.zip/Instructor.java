import java.util.ArrayList;
import java.util.List;

public class Instructor extends Person {
    private List<Course> courses;

    public Instructor(String name, String id) {
        super(name, id);
        courses = new ArrayList<>();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void displayInfo() {
        System.out.println("Instructor Name: " + getName());
        System.out.println("Instructor ID: " + getId());
    }
}