public class Main {
    public static void main(String[] args) {
        StudentManagementSystem sms = new StudentManagementSystem();

        Student student1 = new Student("Alice", "S001");
        Student student2 = new Student("Bob", "S002");

        Course course1 = new Course("Math", "C001");
        Course course2 = new Course("Science", "C002");

        sms.addStudent(student1);
        sms.addStudent(student2);

        sms.addCourse(course1);
        sms.addCourse(course2);

        sms.recordGrade("S001", course1, new Grade(85));
        sms.recordGrade("S001", course2, new Grade(90));
        sms.recordGrade("S002", course1, new Grade(78));

        System.out.println("Average Grade for Alice: " + sms.calculateAverageGrade("S001"));
        System.out.println("Average Grade for Bob: " + sms.calculateAverageGrade("S002"));
    }
}